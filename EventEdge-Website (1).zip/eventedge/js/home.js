document.addEventListener("DOMContentLoaded", () => {
  /* ---- Featured slider ---- */
  const featured = EVENTS.filter(e => e.featured);
  const track = document.getElementById("featuredSlider");
  const dotsWrap = document.getElementById("sliderDots");
  let slideIndex = 0;

  track.innerHTML = featured.map((ev, i) => `
    <div class="slide ${i === 0 ? "active" : ""}" data-i="${i}">
      <div class="ticket" style="height:100%;">
        <a href="event-details.html?id=${ev.id}" class="ticket-media" style="aspect-ratio:auto; height:60%;">
          <img src="${ev.image}" alt="${ev.title}">
          <span class="ticket-cat">Featured · ${ev.category}</span>
        </a>
        <div class="ticket-body">
          <h3>${ev.title}</h3>
          <div class="ticket-meta">
            <span>📅 ${formatEventDate(ev.date)}</span>
            <span>📍 ${ev.location}</span>
          </div>
        </div>
        <div class="ticket-perf"></div>
        <div class="ticket-foot">
          <div class="ticket-price">${formatPrice(ev.price)}<small>per ticket</small></div>
          <a href="event-details.html?id=${ev.id}" class="btn btn-primary btn-sm">View</a>
        </div>
      </div>
    </div>
  `).join("");

  dotsWrap.innerHTML = featured.map((_, i) => `<button data-i="${i}" class="${i === 0 ? "active" : ""}" aria-label="Slide ${i+1}"></button>`).join("");

  function goToSlide(i) {
    slideIndex = (i + featured.length) % featured.length;
    track.querySelectorAll(".slide").forEach(s => s.classList.toggle("active", Number(s.dataset.i) === slideIndex));
    dotsWrap.querySelectorAll("button").forEach(b => b.classList.toggle("active", Number(b.dataset.i) === slideIndex));
  }
  document.getElementById("sliderPrev").addEventListener("click", () => goToSlide(slideIndex - 1));
  document.getElementById("sliderNext").addEventListener("click", () => goToSlide(slideIndex + 1));
  dotsWrap.querySelectorAll("button").forEach(b => b.addEventListener("click", () => goToSlide(Number(b.dataset.i))));
  setInterval(() => goToSlide(slideIndex + 1), 5500);

  /* ---- Category strip ---- */
  const cats = [...new Set(EVENTS.map(e => e.category))];
  document.getElementById("categoryStrip").innerHTML = cats.map(c => `
    <a href="events.html?category=${encodeURIComponent(c)}" class="cat-pill">
      <span>${CATEGORY_ICONS[c] || "🎫"}</span> ${c}
      <span style="opacity:.55; font-family:var(--font-mono); font-size:.78rem;">(${EVENTS.filter(e => e.category === c).length})</span>
    </a>
  `).join("");

  /* ---- Popular grid (top 8 by popularity) ---- */
  const popular = [...EVENTS].sort((a, b) => b.popularity - a.popularity).slice(0, 8);
  document.getElementById("popularGrid").innerHTML = popular.map(ticketCardHTML).join("");
  bindFavButtons();

  /* ---- Hero search ---- */
  document.getElementById("heroSearchForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const q = document.getElementById("heroSearchInput").value.trim();
    window.location.href = `events.html?q=${encodeURIComponent(q)}`;
  });

  /* ---- Countdown to nearest upcoming event ---- */
  const upcoming = [...EVENTS].filter(e => new Date(e.date) > new Date()).sort((a, b) => new Date(a.date) - new Date(b.date))[0];
  if (upcoming) {
    document.getElementById("countdownTitle").textContent = upcoming.title;
    document.getElementById("countdownSub").textContent = `${formatEventDate(upcoming.date)} · ${upcoming.location}`;
    document.getElementById("countdownLink").href = `event-details.html?id=${upcoming.id}`;
    startCountdown(upcoming.date, {
      d: document.getElementById("cd-d"), h: document.getElementById("cd-h"),
      m: document.getElementById("cd-m"), s: document.getElementById("cd-s")
    });
  }
});
