function renderFavorites() {
  const favIds = getFavorites();
  const favEvents = EVENTS.filter(e => favIds.includes(e.id));
  const grid = document.getElementById("favGrid");
  const empty = document.getElementById("favEmpty");

  if (favEvents.length === 0) {
    grid.innerHTML = "";
    empty.style.display = "block";
  } else {
    empty.style.display = "none";
    grid.innerHTML = favEvents.map(ticketCardHTML).join("");
    bindFavButtons();
  }
}

function renderRegistrations() {
  const regs = getRegistrations();
  const list = document.getElementById("regList");
  const empty = document.getElementById("regEmpty");

  if (regs.length === 0) {
    list.innerHTML = "";
    empty.style.display = "block";
    return;
  }
  empty.style.display = "none";
  list.innerHTML = regs.map(r => {
    const ev = EVENTS.find(e => e.id === r.eventId);
    return `
    <div class="mini-row">
      <img src="${ev ? ev.image : "https://picsum.photos/seed/fallback/100/100"}" alt="${r.eventTitle}">
      <div class="grow">
        <h4>${r.eventTitle}</h4>
        <span>${r.qty} ticket(s) · ${formatPrice(r.total)} · Conf# ${r.confId}</span>
      </div>
      ${ev ? `<a href="event-details.html?id=${ev.id}" class="btn btn-ghost btn-sm">View</a>` : ""}
    </div>`;
  }).join("");
}

document.addEventListener("DOMContentLoaded", () => {
  renderFavorites();
  renderRegistrations();

  document.getElementById("clearFavBtn").addEventListener("click", () => {
    if (getFavorites().length === 0) return;
    localStorage.setItem(LS_FAV, "[]");
    updateFavBadge();
    renderFavorites();
    showToast("All favorites cleared");
  });

  document.addEventListener("favorites-changed", renderFavorites);
});
