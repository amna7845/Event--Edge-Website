const LS_USERS = "ee_users";

function getUsers() {
  const users = JSON.parse(localStorage.getItem(LS_USERS) || "[]");
  // Seed a demo account if none exist yet
  if (users.length === 0) {
    const seeded = [{ name: "Demo User", email: "demo@eventedge.com", password: "demo1234" }];
    localStorage.setItem(LS_USERS, JSON.stringify(seeded));
    return seeded;
  }
  return users;
}
function saveUsers(users) {
  localStorage.setItem(LS_USERS, JSON.stringify(users));
}

function showDashboard() {
  const user = getCurrentUser();
  document.getElementById("authCard").style.display = "none";
  document.getElementById("dashboardCard").style.display = "block";
  document.getElementById("dashAvatar").textContent = user.name.charAt(0).toUpperCase();
  document.getElementById("dashName").textContent = user.name;
  document.getElementById("dashEmail").textContent = user.email;
  document.getElementById("dashFavCount").textContent = getFavorites().length;
  document.getElementById("dashRegCount").textContent = getRegistrations().length;
}
function showAuthForms() {
  document.getElementById("authCard").style.display = "block";
  document.getElementById("dashboardCard").style.display = "none";
}

document.addEventListener("DOMContentLoaded", () => {
  getUsers(); // ensure demo account exists

  if (getCurrentUser()) {
    showDashboard();
  } else {
    showAuthForms();
  }

  // Tabs
  const tabLogin = document.getElementById("tabLogin");
  const tabRegister = document.getElementById("tabRegister");
  const panelLogin = document.getElementById("panelLogin");
  const panelRegister = document.getElementById("panelRegister");
  tabLogin.addEventListener("click", () => {
    tabLogin.classList.add("active"); tabRegister.classList.remove("active");
    panelLogin.classList.add("active"); panelRegister.classList.remove("active");
  });
  tabRegister.addEventListener("click", () => {
    tabRegister.classList.add("active"); tabLogin.classList.remove("active");
    panelRegister.classList.add("active"); panelLogin.classList.remove("active");
  });

  // Login
  document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const emailEl = document.getElementById("liEmail");
    const passEl = document.getElementById("liPassword");
    [emailEl, passEl].forEach(f => { f.closest(".form-group").classList.remove("invalid"); f.closest(".form-group").querySelector(".error-msg").textContent = ""; });

    let valid = true;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailEl.value)) { markInvalid(emailEl, "Enter a valid email"); valid = false; }
    if (!passEl.value) { markInvalid(passEl, "Enter your password"); valid = false; }
    if (!valid) return;

    const users = getUsers();
    const found = users.find(u => u.email.toLowerCase() === emailEl.value.toLowerCase() && u.password === passEl.value);
    if (!found) {
      markInvalid(passEl, "Incorrect email or password");
      showToast("Login failed — check your details");
      return;
    }
    setCurrentUser({ name: found.name, email: found.email });
    showToast(`Welcome back, ${found.name.split(" ")[0]}!`);
    showDashboard();
  });

  // Register
  document.getElementById("registerForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const nameEl = document.getElementById("roName");
    const emailEl = document.getElementById("roEmail");
    const passEl = document.getElementById("roPassword");
    const confirmEl = document.getElementById("roConfirm");
    [nameEl, emailEl, passEl, confirmEl].forEach(f => { f.closest(".form-group").classList.remove("invalid"); f.closest(".form-group").querySelector(".error-msg").textContent = ""; });

    let valid = true;
    if (nameEl.value.trim().length < 2) { markInvalid(nameEl, "Enter your full name"); valid = false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailEl.value)) { markInvalid(emailEl, "Enter a valid email"); valid = false; }
    if (passEl.value.length < 6) { markInvalid(passEl, "Password must be at least 6 characters"); valid = false; }
    if (confirmEl.value !== passEl.value) { markInvalid(confirmEl, "Passwords don't match"); valid = false; }

    const users = getUsers();
    if (users.some(u => u.email.toLowerCase() === emailEl.value.toLowerCase())) {
      markInvalid(emailEl, "An account with this email already exists");
      valid = false;
    }
    if (!valid) return;

    const newUser = { name: nameEl.value.trim(), email: emailEl.value.trim(), password: passEl.value };
    users.push(newUser);
    saveUsers(users);
    setCurrentUser({ name: newUser.name, email: newUser.email });
    showToast("Account created — you're logged in!");
    showDashboard();
  });

  // Logout
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) logoutBtn.addEventListener("click", () => {
    logoutUser();
    showAuthForms();
  });

  function markInvalid(field, msg) {
    const group = field.closest(".form-group");
    group.classList.add("invalid");
    group.querySelector(".error-msg").textContent = msg;
  }
});
