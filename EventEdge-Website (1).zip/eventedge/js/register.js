document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id")) || EVENTS[0].id;
  const startQty = Number(params.get("qty")) || 1;
  const ev = EVENTS.find(e => e.id === id) || EVENTS[0];

  document.getElementById("sumImg").src = ev.image;
  document.getElementById("sumTitle").textContent = ev.title;
  document.getElementById("sumMeta").textContent = `${formatEventDate(ev.date)} · ${ev.location} · ${formatPrice(ev.price)}/ticket`;

  const qtyInput = document.getElementById("regQty");
  qtyInput.value = Math.min(10, Math.max(1, startQty));
  const totalEl = document.getElementById("regTotal");
  const qtyLabel = document.getElementById("qtyLabel");

  function updateTotal() {
    let q = Number(qtyInput.value) || 1;
    q = Math.min(10, Math.max(1, q));
    qtyLabel.textContent = q;
    totalEl.textContent = formatPrice(q * ev.price);
  }
  qtyInput.addEventListener("input", updateTotal);
  updateTotal();

  const fields = {
    regName: { validate: v => v.trim().length >= 2, msg: "Enter your full name (min 2 characters)" },
    regEmail: { validate: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), msg: "Enter a valid email address" },
    regPhone: { validate: v => /^[0-9+\-\s]{7,15}$/.test(v), msg: "Enter a valid phone number" },
    regQty: { validate: v => Number(v) >= 1 && Number(v) <= 10, msg: "Choose between 1 and 10 tickets" },
    regPayment: { validate: v => v !== "", msg: "Select a payment method" },
  };

  function validateField(id) {
    const el = document.getElementById(id);
    const group = el.closest(".form-group");
    const rule = fields[id];
    const ok = rule.validate(el.value);
    group.classList.toggle("invalid", !ok);
    group.classList.toggle("valid", ok);
    group.querySelector(".error-msg").textContent = ok ? "" : rule.msg;
    return ok;
  }

  Object.keys(fields).forEach(id => {
    document.getElementById(id).addEventListener("blur", () => validateField(id));
    document.getElementById(id).addEventListener("input", () => validateField(id));
  });

  document.getElementById("registrationForm").addEventListener("submit", (e) => {
    e.preventDefault();
    let allValid = Object.keys(fields).map(validateField).every(Boolean);

    const termsGroup = document.getElementById("regTerms").closest(".form-group");
    const termsOk = document.getElementById("regTerms").checked;
    termsGroup.classList.toggle("invalid", !termsOk);
    termsGroup.querySelector(".error-msg").textContent = termsOk ? "" : "You must accept the terms to continue";
    if (!termsOk) allValid = false;

    if (!allValid) {
      showToast("Please fix the highlighted fields");
      return;
    }

    const qty = Number(qtyInput.value);
    const total = qty * ev.price;
    const confId = "EE-" + Math.random().toString(36).slice(2, 8).toUpperCase();

    addRegistration({
      confId, eventId: ev.id, eventTitle: ev.title, date: ev.date, location: ev.location,
      name: document.getElementById("regName").value.trim(),
      email: document.getElementById("regEmail").value.trim(),
      qty, total, createdAt: new Date().toISOString()
    });

    document.getElementById("regFormWrap").style.display = "none";
    const confirmBox = document.getElementById("confirmBox");
    confirmBox.style.display = "block";
    document.getElementById("confirmText").textContent = `A confirmation has been sent for "${ev.title}". Keep your confirmation ID for check-in.`;
    document.getElementById("confId").textContent = confId;
    document.getElementById("confEvent").textContent = ev.title;
    document.getElementById("confQty").textContent = qty;
    document.getElementById("confTotal").textContent = formatPrice(total);

    showToast("Registration confirmed 🎉");
    confirmBox.scrollIntoView({ behavior: "smooth", block: "start" });
  });
});
