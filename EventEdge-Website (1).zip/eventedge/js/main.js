/* ============================================================
   EventEdge — Shared site behaviour
   Loaded on every page after data.js
   ============================================================ */

/* ---------- Storage keys ---------- */
const LS_FAV = "ee_favorites";
const LS_REG = "ee_registrations";
const LS_USER = "ee_user";
const LS_THEME = "ee_theme";
const LS_CREATED = "ee_created_events";

/* ---------- Favorites ---------- */
function getFavorites() {
  return JSON.parse(localStorage.getItem(LS_FAV) || "[]");
}
function isFavorite(id) {
  return getFavorites().includes(id);
}
function toggleFavorite(id) {
  let favs = getFavorites();
  if (favs.includes(id)) {
    favs = favs.filter(f => f !== id);
  } else {
    favs.push(id);
  }
  localStorage.setItem(LS_FAV, JSON.stringify(favs));
  updateFavBadge();
  return favs.includes(id);
}
function updateFavBadge() {
  const badge = document.getElementById("favBadge");
  if (!badge) return;
  const count = getFavorites().length;
  badge.textContent = count;
  badge.style.display = count > 0 ? "flex" : "none";
}

/* ---------- Registrations ---------- */
function getRegistrations() {
  return JSON.parse(localStorage.getItem(LS_REG) || "[]");
}
function addRegistration(reg) {
  const regs = getRegistrations();
  regs.unshift(reg);
  localStorage.setItem(LS_REG, JSON.stringify(regs));
}

/* ---------- Auth (local-storage only, demo purposes) ---------- */
function getCurrentUser() {
  return JSON.parse(localStorage.getItem(LS_USER) || "null");
}
function setCurrentUser(user) {
  localStorage.setItem(LS_USER, JSON.stringify(user));
  updateAuthUI();
}
function logoutUser() {
  localStorage.removeItem(LS_USER);
  updateAuthUI();
  showToast("You've been logged out");
}
function updateAuthUI() {
  const user = getCurrentUser();
  const authBtn = document.getElementById("authIconBtn");
  if (!authBtn) return;
  if (user) {
    authBtn.innerHTML = `<span>${user.name.charAt(0).toUpperCase()}</span>`;
    authBtn.setAttribute("href", "login.html");
    authBtn.title = `Signed in as ${user.name}`;
  } else {
    authBtn.innerHTML = `<span>👤</span>`;
    authBtn.setAttribute("href", "login.html");
    authBtn.title = "Login / Register";
  }
}

/* ---------- Theme (dark / light) ---------- */
function initTheme() {
  const saved = localStorage.getItem(LS_THEME) || "dark";
  document.documentElement.setAttribute("data-theme", saved);
  const btn = document.getElementById("themeToggle");
  if (btn) {
    btn.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme");
      const next = current === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      localStorage.setItem(LS_THEME, next);
    });
  }
}

/* ---------- Navbar: hamburger + active link + sticky shadow ---------- */
function initNavbar() {
  const burger = document.getElementById("hamburger");
  const links = document.getElementById("navLinks");
  if (burger && links) {
    burger.addEventListener("click", () => {
      burger.classList.toggle("open");
      links.classList.toggle("open");
    });
    links.querySelectorAll("a").forEach(a =>
      a.addEventListener("click", () => {
        burger.classList.remove("open");
        links.classList.remove("open");
      })
    );
  }
  // Mark active link based on current filename
  const current = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach(a => {
    const href = a.getAttribute("href");
    if (href === current) a.classList.add("active");
  });
}

/* ---------- Scroll-to-top button ---------- */
function initScrollTop() {
  const btn = document.getElementById("scrollTopBtn");
  if (!btn) return;
  window.addEventListener("scroll", () => {
    btn.classList.toggle("show", window.scrollY > 500);
  });
  btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

/* ---------- Toast ---------- */
let toastTimer;
function showToast(message) {
  let toast = document.getElementById("globalToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "globalToast";
    toast.className = "toast";
    toast.innerHTML = `<span class="dot"></span><span id="globalToastText"></span>`;
    document.body.appendChild(toast);
  }
  document.getElementById("globalToastText").textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

/* ---------- Ticket-stub card renderer (used across pages) ---------- */
function ticketCardHTML(ev) {
  const fav = isFavorite(ev.id);
  return `
  <article class="ticket reveal" data-id="${ev.id}">
    <a href="event-details.html?id=${ev.id}" class="ticket-media">
      <img src="${ev.image}" alt="${ev.title}" loading="lazy">
      <span class="ticket-cat">${ev.category}</span>
    </a>
    <button class="fav-toggle ${fav ? "active" : ""}" data-fav-id="${ev.id}" aria-label="Toggle favorite" title="Save to favorites">
      ${fav ? "♥" : "♡"}
    </button>
    <a href="event-details.html?id=${ev.id}" class="ticket-body">
      <h3>${ev.title}</h3>
      <div class="ticket-meta">
        <span>📅 ${formatEventDate(ev.date)}</span>
        <span>📍 ${ev.location}</span>
        <span>🎟️ ${ev.organizer}</span>
      </div>
    </a>
    <div class="ticket-perf"></div>
    <div class="ticket-foot">
      <div class="ticket-price">${formatPrice(ev.price)}<small>per ticket</small></div>
      <a href="event-details.html?id=${ev.id}" class="btn btn-primary btn-sm">View</a>
    </div>
  </article>`;
}

function bindFavButtons(root = document) {
  root.querySelectorAll("[data-fav-id]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const id = Number(btn.dataset.favId);
      const nowFav = toggleFavorite(id);
      btn.classList.toggle("active", nowFav);
      btn.textContent = nowFav ? "♥" : "♡";
      showToast(nowFav ? "Added to favorites" : "Removed from favorites");
      document.dispatchEvent(new CustomEvent("favorites-changed"));
    });
  });
}

/* ---------- Generic countdown ---------- */
function startCountdown(targetDate, els) {
  function tick() {
    const now = new Date().getTime();
    const dist = new Date(targetDate).getTime() - now;
    if (dist <= 0) {
      els.d.textContent = els.h.textContent = els.m.textContent = els.s.textContent = "00";
      clearInterval(timer);
      return;
    }
    const d = Math.floor(dist / 86400000);
    const h = Math.floor((dist % 86400000) / 3600000);
    const m = Math.floor((dist % 3600000) / 60000);
    const s = Math.floor((dist % 60000) / 1000);
    els.d.textContent = String(d).padStart(2, "0");
    els.h.textContent = String(h).padStart(2, "0");
    els.m.textContent = String(m).padStart(2, "0");
    els.s.textContent = String(s).padStart(2, "0");
  }
  tick();
  const timer = setInterval(tick, 1000);
  return timer;
}

/* ---------- Footer year ---------- */
function setFooterYear() {
  document.querySelectorAll(".footer-year").forEach(el => el.textContent = new Date().getFullYear());
}

/* ---------- Init everything shared ---------- */
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initNavbar();
  initScrollTop();
  updateFavBadge();
  updateAuthUI();
  setFooterYear();
});
