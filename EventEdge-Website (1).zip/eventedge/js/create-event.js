function getCreatedEvents() {
  return JSON.parse(localStorage.getItem(LS_CREATED) || "[]");
}
function saveCreatedEvent(ev) {
  const list = getCreatedEvents();
  list.unshift(ev);
  localStorage.setItem(LS_CREATED, JSON.stringify(list));
}

function renderMyEvents() {
  const list = getCreatedEvents();
  const wrap = document.getElementById("myEventsList");
  const emptyMsg = document.getElementById("myEventsEmpty");
  if (list.length === 0) {
    wrap.innerHTML = "";
    emptyMsg.style.display = "block";
    return;
  }
  emptyMsg.style.display = "none";
  wrap.innerHTML = list.map(ev => `
    <div class="mini-row">
      <img src="${ev.image}" alt="${ev.title}">
      <div class="grow">
        <h4>${ev.title}</h4>
        <span>${ev.category} · ${formatEventDate(ev.date)}</span>
      </div>
    </div>
  `).join("");
}

document.addEventListener("DOMContentLoaded", () => {
  renderMyEvents();

  const fields = {
    ceTitle: v => v.trim().length >= 4,
    ceCategory: v => v !== "",
    ceOrganizer: v => v.trim().length >= 2,
    ceDate: v => v !== "" && new Date(v) >= new Date(new Date().toDateString()),
    ceTime: v => v !== "",
    ceLocation: v => v.trim().length >= 3,
    cePrice: v => Number(v) >= 0 && v !== "",
    ceCapacity: v => Number(v) >= 1 && v !== "",
    ceDescription: v => v.trim().length >= 15,
  };
  const messages = {
    ceTitle: "Title should be at least 4 characters",
    ceCategory: "Please choose a category",
    ceOrganizer: "Enter an organizer name",
    ceDate: "Choose today or a future date",
    ceTime: "Choose a start time",
    ceLocation: "Enter a venue and city",
    cePrice: "Enter a valid ticket price (0 or more)",
    ceCapacity: "Enter a capacity of at least 1",
    ceDescription: "Add a short description (15+ characters)",
  };

  function validateField(id) {
    const el = document.getElementById(id);
    const group = el.closest(".form-group");
    const ok = fields[id](el.value);
    group.classList.toggle("invalid", !ok);
    group.classList.toggle("valid", ok);
    group.querySelector(".error-msg").textContent = ok ? "" : messages[id];
    return ok;
  }

  Object.keys(fields).forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener("blur", () => validateField(id));
    el.addEventListener("input", () => validateField(id));
  });

  document.getElementById("createEventForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const allValid = Object.keys(fields).map(validateField).every(Boolean);
    if (!allValid) { showToast("Please fix the highlighted fields"); return; }

    const seedRaw = document.getElementById("ceImageSeed").value.trim() || document.getElementById("ceTitle").value.trim();
    const seed = seedRaw.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40) || "eventedge";
    const image = `https://picsum.photos/seed/${seed}/900/600`;

    const newEvent = {
      id: "custom-" + Date.now(),
      title: document.getElementById("ceTitle").value.trim(),
      category: document.getElementById("ceCategory").value,
      organizer: document.getElementById("ceOrganizer").value.trim(),
      date: `${document.getElementById("ceDate").value}T${document.getElementById("ceTime").value}`,
      location: document.getElementById("ceLocation").value.trim(),
      price: Number(document.getElementById("cePrice").value),
      capacity: Number(document.getElementById("ceCapacity").value),
      description: document.getElementById("ceDescription").value.trim(),
      image, gallery: [image, image, image],
      tags: ["New", "Community Submitted"],
      popularity: 50
    };

    saveCreatedEvent(newEvent);
    renderMyEvents();

    document.getElementById("createFormWrap").style.display = "none";
    const confirmBox = document.getElementById("createConfirm");
    confirmBox.style.display = "block";

    document.getElementById("createdPreview").innerHTML = `
      <article class="ticket">
        <div class="ticket-media"><img src="${newEvent.image}" alt="${newEvent.title}"><span class="ticket-cat">${newEvent.category}</span></div>
        <div class="ticket-body">
          <h3>${newEvent.title}</h3>
          <div class="ticket-meta">
            <span>📅 ${formatEventDate(newEvent.date)}</span>
            <span>📍 ${newEvent.location}</span>
            <span>🎟️ ${newEvent.organizer}</span>
          </div>
        </div>
        <div class="ticket-perf"></div>
        <div class="ticket-foot">
          <div class="ticket-price">${formatPrice(newEvent.price)}<small>per ticket</small></div>
        </div>
      </article>`;

    showToast("Event published to this device 🎉");
    confirmBox.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  document.getElementById("createAnotherBtn").addEventListener("click", () => {
    document.getElementById("createEventForm").reset();
    document.querySelectorAll("#createEventForm .form-group").forEach(g => g.classList.remove("valid", "invalid"));
    document.getElementById("createConfirm").style.display = "none";
    document.getElementById("createFormWrap").style.display = "block";
  });
});
