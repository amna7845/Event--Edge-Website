const CATEGORY_DESC = {
  Wedding: "Ceremonies, receptions and everything in between — from beach vows to ballroom galas.",
  Concert: "Live music nights across genres, from unplugged acoustic sets to full-scale festivals.",
  Corporate: "Summits, kickoffs and launches built for teams, founders and partners.",
  Birthday: "Themed parties for every age, from bounce-castle bashes to rooftop milestones.",
  Sports: "Races, matches and tournaments for players and spectators alike.",
  Conference: "Talks, panels and workshops from the people shaping their fields."
};

document.addEventListener("DOMContentLoaded", () => {
  const cats = [...new Set(EVENTS.map(e => e.category))];

  document.getElementById("categoriesGrid").innerHTML = cats.map(c => {
    const count = EVENTS.filter(e => e.category === c).length;
    return `
    <a href="events.html?category=${encodeURIComponent(c)}" class="category-card reveal">
      <span class="cat-icon">${CATEGORY_ICONS[c] || "🎫"}</span>
      <h3>${c}</h3>
      <p>${CATEGORY_DESC[c] || ""}</p>
      <span class="count">${count} event${count !== 1 ? "s" : ""} →</span>
    </a>`;
  }).join("");

  const previewSection = document.getElementById("categoryPreviewSection");
  previewSection.innerHTML = cats.map(c => {
    const items = EVENTS.filter(e => e.category === c).slice(0, 3);
    return `
    <div class="container" style="margin-bottom:56px;">
      <div class="results-bar">
        <div class="section-head" style="margin-bottom:0;">
          <div class="eyebrow">${CATEGORY_ICONS[c] || ""} ${c}</div>
          <h2 style="font-size:1.6rem;">Popular ${c.toLowerCase()} events</h2>
        </div>
        <a href="events.html?category=${encodeURIComponent(c)}" class="btn btn-ghost">See all ${c} →</a>
      </div>
      <div class="events-grid">${items.map(ticketCardHTML).join("")}</div>
    </div>`;
  }).join("");

  bindFavButtons();
});
