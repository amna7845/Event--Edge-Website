document.addEventListener("DOMContentLoaded", () => {
  const grid = document.getElementById("eventsGrid");
  const emptyState = document.getElementById("emptyState");
  const resultsCount = document.getElementById("resultsCount");

  const fSearch = document.getElementById("fSearch");
  const fCategory = document.getElementById("fCategory");
  const fLocation = document.getElementById("fLocation");
  const fDate = document.getElementById("fDate");
  const fPrice = document.getElementById("fPrice");
  const fPriceVal = document.getElementById("fPriceVal");
  const fSort = document.getElementById("fSort");
  const clearBtn = document.getElementById("clearFilters");

  // Populate category + location dropdowns dynamically
  const categories = [...new Set(EVENTS.map(e => e.category))].sort();
  fCategory.innerHTML += categories.map(c => `<option value="${c}">${c}</option>`).join("");

  const locations = [...new Set(EVENTS.map(e => e.location.split(",").pop().trim()))].sort();
  fLocation.innerHTML += locations.map(l => `<option value="${l}">${l}</option>`).join("");

  // Read query params (from home page search / category links)
  const params = new URLSearchParams(window.location.search);
  if (params.get("q")) fSearch.value = params.get("q");
  if (params.get("category")) fCategory.value = params.get("category");

  function applyFilters() {
    const q = fSearch.value.trim().toLowerCase();
    const cat = fCategory.value;
    const loc = fLocation.value;
    const date = fDate.value;
    const maxPrice = Number(fPrice.value);
    fPriceVal.textContent = formatPrice(maxPrice);

    let list = EVENTS.filter(ev => {
      const matchesQ = !q || ev.title.toLowerCase().includes(q) || ev.location.toLowerCase().includes(q) || ev.organizer.toLowerCase().includes(q) || ev.category.toLowerCase().includes(q);
      const matchesCat = !cat || ev.category === cat;
      const matchesLoc = !loc || ev.location.includes(loc);
      const matchesDate = !date || ev.date.slice(0, 10) === date;
      const matchesPrice = ev.price <= maxPrice;
      return matchesQ && matchesCat && matchesLoc && matchesDate && matchesPrice;
    });

    switch (fSort.value) {
      case "price-asc": list.sort((a, b) => a.price - b.price); break;
      case "price-desc": list.sort((a, b) => b.price - a.price); break;
      case "date-asc": list.sort((a, b) => new Date(a.date) - new Date(b.date)); break;
      case "date-desc": list.sort((a, b) => new Date(b.date) - new Date(a.date)); break;
      default: list.sort((a, b) => b.popularity - a.popularity);
    }

    resultsCount.textContent = `${list.length} event${list.length !== 1 ? "s" : ""} found`;

    if (list.length === 0) {
      grid.innerHTML = "";
      emptyState.style.display = "block";
    } else {
      emptyState.style.display = "none";
      grid.innerHTML = list.map(ticketCardHTML).join("");
      bindFavButtons();
    }
  }

  [fSearch, fCategory, fLocation, fDate, fSort].forEach(el => el.addEventListener("input", applyFilters));
  fPrice.addEventListener("input", applyFilters);
  clearBtn.addEventListener("click", () => {
    fSearch.value = ""; fCategory.value = ""; fLocation.value = ""; fDate.value = "";
    fPrice.value = 22000; fSort.value = "popularity";
    applyFilters();
  });
  document.addEventListener("favorites-changed", () => {}); // cards re-render on toggle already

  applyFilters();
});
