/* ============================================================
   EventEdge — Event Dataset
   Single source of truth for every event shown across the site.
   ============================================================ */

const IMG = (seed, w = 900, h = 600) => `https://picsum.photos/seed/${seed}/${w}/${h}`;

const EVENTS = [
  {
    id: 1, title: "Golden Hour Vows", category: "Wedding",
    date: "2026-09-12T16:30", location: "Sunset Vineyard, Lahore", price: 15000,
    organizer: "Ivory & Oak Weddings", popularity: 92, featured: true,
    image: IMG("wedding1"), gallery: [IMG("wedding1"), IMG("wedding1b"), IMG("wedding1c")],
    description: "An open-air vineyard ceremony at golden hour, followed by a candlelit reception under draped florals. Includes seating for 200 guests, live string quartet, and a five-course tasting menu.",
    tags: ["Outdoor", "Reception", "Live Music"]
  },
  {
    id: 2, title: "The Rosewood Union", category: "Wedding",
    date: "2026-10-03T17:00", location: "Rosewood Hall, Karachi", price: 22000,
    organizer: "Bloom Events Co.", popularity: 78, featured: false,
    image: IMG("wedding2"), gallery: [IMG("wedding2"), IMG("wedding2b"), IMG("wedding2c")],
    description: "A grand ballroom wedding with crystal chandeliers, a curated flower wall, and a dedicated bridal suite. Full-service catering and valet parking included.",
    tags: ["Indoor", "Luxury", "Catering"]
  },
  {
    id: 3, title: "Barefoot Beach Ceremony", category: "Wedding",
    date: "2026-11-20T15:00", location: "Clifton Shoreline, Karachi", price: 9800,
    organizer: "Salt & Aisle", popularity: 65, featured: false,
    image: IMG("wedding3"), gallery: [IMG("wedding3"), IMG("wedding3b"), IMG("wedding3c")],
    description: "A relaxed, barefoot-in-the-sand ceremony with a driftwood arch and acoustic sunset set. Casual reception with a bonfire and food trucks to follow.",
    tags: ["Beach", "Casual", "Sunset"]
  },
  {
    id: 4, title: "Mehendi & Marigolds", category: "Wedding",
    date: "2026-09-28T18:00", location: "Garden Pavilion, Lahore", price: 7200,
    organizer: "Ivory & Oak Weddings", popularity: 71, featured: false,
    image: IMG("wedding4"), gallery: [IMG("wedding4"), IMG("wedding4b"), IMG("wedding4c")],
    description: "A vibrant pre-wedding mehendi night with live dhol, marigold-strung canopies, and a henna artist lounge for guests.",
    tags: ["Traditional", "Music", "Dance"]
  },

  {
    id: 5, title: "Neon Skyline Fest", category: "Concert",
    date: "2026-08-30T20:00", location: "Skyline Arena, Lahore", price: 4500,
    organizer: "Pulse Live", popularity: 97, featured: true,
    image: IMG("concert1"), gallery: [IMG("concert1"), IMG("concert1b"), IMG("concert1c")],
    description: "A three-headliner night of electronic and indie acts on a full LED stage, with pyrotechnics and an elevated VIP deck overlooking the crowd.",
    tags: ["EDM", "Night", "VIP Deck"]
  },
  {
    id: 6, title: "Acoustic Under the Stars", category: "Concert",
    date: "2026-09-05T19:30", location: "Open Air Theatre, Islamabad", price: 2800,
    organizer: "Quiet Nights Live", popularity: 84, featured: false,
    image: IMG("concert2"), gallery: [IMG("concert2"), IMG("concert2b"), IMG("concert2c")],
    description: "An intimate unplugged evening with rotating singer-songwriters, blanket seating on the lawn, and a bring-your-own-picnic policy.",
    tags: ["Acoustic", "Outdoor", "Chill"]
  },
  {
    id: 7, title: "Bassline Warehouse Rave", category: "Concert",
    date: "2026-10-17T22:00", location: "Warehouse 9, Karachi", price: 3800,
    organizer: "Pulse Live", popularity: 89, featured: false,
    image: IMG("concert3"), gallery: [IMG("concert3"), IMG("concert3b"), IMG("concert3c")],
    description: "A late-night warehouse set with a stacked bassline lineup, industrial visuals, and a 24-hour licensed bar.",
    tags: ["Techno", "Late Night", "18+"]
  },
  {
    id: 8, title: "Symphony at Dusk", category: "Concert",
    date: "2026-12-01T18:00", location: "City Concert Hall, Lahore", price: 5200,
    organizer: "Lahore Philharmonic", popularity: 73, featured: false,
    image: IMG("concert4"), gallery: [IMG("concert4"), IMG("concert4b"), IMG("concert4c")],
    description: "A full orchestral performance of contemporary film scores, with a pre-show lobby reception and programme notes from the conductor.",
    tags: ["Orchestra", "Formal", "Indoor"]
  },

  {
    id: 9, title: "Founders Summit 2026", category: "Corporate",
    date: "2026-09-19T09:00", location: "Innovation Center, Lahore", price: 12000,
    organizer: "Northbridge Ventures", popularity: 88, featured: true,
    image: IMG("corp1"), gallery: [IMG("corp1"), IMG("corp1b"), IMG("corp1c")],
    description: "A day of keynotes, pitch sessions, and closed-door investor roundtables for early-stage founders, ending with a rooftop networking mixer.",
    tags: ["Networking", "Keynotes", "Startups"]
  },
  {
    id: 10, title: "Annual Sales Kickoff", category: "Corporate",
    date: "2026-08-25T10:00", location: "Grand Convention Hall, Karachi", price: 6000,
    organizer: "Meridian Group", popularity: 61, featured: false,
    image: IMG("corp2"), gallery: [IMG("corp2"), IMG("corp2b"), IMG("corp2c")],
    description: "Full-day team alignment session with breakout workshops, award ceremonies, and a catered awards dinner in the evening.",
    tags: ["Team", "Awards", "Workshops"]
  },
  {
    id: 11, title: "Women in Tech Forum", category: "Corporate",
    date: "2026-10-09T09:30", location: "Tech Park Auditorium, Islamabad", price: 3000,
    organizer: "Circuit Collective", popularity: 82, featured: false,
    image: IMG("corp3"), gallery: [IMG("corp3"), IMG("corp3b"), IMG("corp3c")],
    description: "Panel discussions and mentorship tables for women building careers in technology, with resume clinics running throughout the day.",
    tags: ["Panels", "Mentorship", "Career"]
  },
  {
    id: 12, title: "Product Launch: Horizon", category: "Corporate",
    date: "2026-09-02T17:00", location: "Glass Atrium, Lahore", price: 4000,
    organizer: "Horizon Labs", popularity: 76, featured: false,
    image: IMG("corp4"), gallery: [IMG("corp4"), IMG("corp4b"), IMG("corp4c")],
    description: "An evening product reveal with a live demo floor, press briefing, and a curated cocktail reception for partners and media.",
    tags: ["Launch", "Media", "Demo"]
  },

  {
    id: 13, title: "Superhero Bash Bounce", category: "Birthday",
    date: "2026-08-22T14:00", location: "Funland Party Hall, Lahore", price: 1800,
    organizer: "Partyland Events", popularity: 69, featured: false,
    image: IMG("bday1"), gallery: [IMG("bday1"), IMG("bday1b"), IMG("bday1c")],
    description: "A superhero-themed kids party with bounce castles, a face-painting booth, and a costumed entertainer meet-and-greet.",
    tags: ["Kids", "Costumes", "Games"]
  },
  {
    id: 14, title: "30 & Fabulous Rooftop Party", category: "Birthday",
    date: "2026-09-14T20:00", location: "Skyline Rooftop, Karachi", price: 3200,
    organizer: "Blush Events", popularity: 74, featured: false,
    image: IMG("bday2"), gallery: [IMG("bday2"), IMG("bday2b"), IMG("bday2c")],
    description: "A milestone birthday celebration with a DJ, cocktail bar, and skyline views, plus a dessert table styled to theme.",
    tags: ["Rooftop", "DJ", "Adults"]
  },
  {
    id: 15, title: "Princess Tea Garden", category: "Birthday",
    date: "2026-10-11T13:00", location: "Botanical Garden, Islamabad", price: 1500,
    organizer: "Partyland Events", popularity: 58, featured: false,
    image: IMG("bday3"), gallery: [IMG("bday3"), IMG("bday3b"), IMG("bday3c")],
    description: "A garden tea party with a princess host, mini cupcake bar, and a flower-crown craft station for little guests.",
    tags: ["Kids", "Garden", "Craft"]
  },
  {
    id: 16, title: "Retro Arcade Night", category: "Birthday",
    date: "2026-11-01T18:30", location: "Pixel Lounge, Lahore", price: 2100,
    organizer: "Blush Events", popularity: 66, featured: false,
    image: IMG("bday4"), gallery: [IMG("bday4"), IMG("bday4b"), IMG("bday4c")],
    description: "An 80s arcade takeover with unlimited game tokens, a neon photo booth, and a build-your-own-sundae bar.",
    tags: ["Retro", "Arcade", "Photo Booth"]
  },

  {
    id: 17, title: "City Marathon 2026", category: "Sports",
    date: "2026-10-25T06:00", location: "Riverside Track, Lahore", price: 1200,
    organizer: "RunPunjab Foundation", popularity: 91, featured: true,
    image: IMG("sport1"), gallery: [IMG("sport1"), IMG("sport1b"), IMG("sport1c")],
    description: "A full/half marathon course along the riverside, with hydration stations every 2km and a post-race finisher festival.",
    tags: ["Running", "Outdoor", "Community"]
  },
  {
    id: 18, title: "Twilight Cricket Cup", category: "Sports",
    date: "2026-09-06T17:30", location: "Gaddafi Grounds, Lahore", price: 900,
    organizer: "Punjab Sports Trust", popularity: 85, featured: false,
    image: IMG("sport2"), gallery: [IMG("sport2"), IMG("sport2b"), IMG("sport2c")],
    description: "A floodlit T20 exhibition match between city select teams, with fan zones, food stalls, and a halftime fireworks show.",
    tags: ["Cricket", "Floodlit", "Family"]
  },
  {
    id: 19, title: "Open Water Swim Challenge", category: "Sports",
    date: "2026-11-08T07:00", location: "Rawal Lake, Islamabad", price: 1500,
    organizer: "Islamabad Aquatics", popularity: 54, featured: false,
    image: IMG("sport3"), gallery: [IMG("sport3"), IMG("sport3b"), IMG("sport3c")],
    description: "A timed open-water swim across three distance categories, with safety kayaks on course and a warm breakfast at the finish.",
    tags: ["Swimming", "Endurance", "Outdoor"]
  },
  {
    id: 20, title: "3v3 Streetball Showdown", category: "Sports",
    date: "2026-08-29T16:00", location: "Downtown Courts, Karachi", price: 700,
    organizer: "Court Culture", popularity: 63, featured: false,
    image: IMG("sport4"), gallery: [IMG("sport4"), IMG("sport4b"), IMG("sport4c")],
    description: "A street basketball tournament with a DJ courtside, dunk contest at halftime, and cash prizes for the winning squad.",
    tags: ["Basketball", "Tournament", "Street"]
  },

  {
    id: 21, title: "Future of AI Conference", category: "Conference",
    date: "2026-09-23T09:00", location: "Expo Center, Lahore", price: 8500,
    organizer: "Cognition Summit", popularity: 94, featured: true,
    image: IMG("conf1"), gallery: [IMG("conf1"), IMG("conf1b"), IMG("conf1c")],
    description: "Two tracks of talks on applied machine learning and policy, with a startup expo floor and a closing fireside chat.",
    tags: ["AI", "Talks", "Expo"]
  },
  {
    id: 22, title: "Climate Action Congress", category: "Conference",
    date: "2026-10-14T09:00", location: "Blue Auditorium, Islamabad", price: 5000,
    organizer: "GreenShift Alliance", popularity: 79, featured: false,
    image: IMG("conf2"), gallery: [IMG("conf2"), IMG("conf2b"), IMG("conf2c")],
    description: "Policy makers and researchers convene on climate resilience strategies, with regional case-study workshops in the afternoon.",
    tags: ["Climate", "Policy", "Workshops"]
  },
  {
    id: 23, title: "Design Systems Conf", category: "Conference",
    date: "2026-11-18T09:30", location: "Creative Hub, Karachi", price: 4200,
    organizer: "Grid & Ink", popularity: 81, featured: false,
    image: IMG("conf3"), gallery: [IMG("conf3"), IMG("conf3b"), IMG("conf3c")],
    description: "A practitioner-led conference on scalable design systems, with live critique sessions and a component-library swap meet.",
    tags: ["Design", "UX", "Workshops"]
  },
  {
    id: 24, title: "HealthTech Frontiers", category: "Conference",
    date: "2026-12-05T09:00", location: "Med Innovation Campus, Lahore", price: 6700,
    organizer: "Cognition Summit", popularity: 70, featured: false,
    image: IMG("conf4"), gallery: [IMG("conf4"), IMG("conf4b"), IMG("conf4c")],
    description: "Clinicians and engineers share research on diagnostic AI and wearable health devices, with a hands-on device showcase.",
    tags: ["HealthTech", "Research", "Showcase"]
  }
];

const CATEGORY_ICONS = {
  Wedding: "💍", Concert: "🎤", Corporate: "💼",
  Birthday: "🎂", Sports: "🏆", Conference: "🎙️"
};

// Utility: format date nicely, e.g. "Sep 12, 2026 · 4:30 PM"
function formatEventDate(iso) {
  const d = new Date(iso);
  const date = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const time = d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  return `${date} · ${time}`;
}

function formatPrice(v) {
  return `PKR ${v.toLocaleString()}`;
}
