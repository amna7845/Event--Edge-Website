document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id")) || EVENTS[0].id;
  const ev = EVENTS.find(e => e.id === id) || EVENTS[0];

  document.title = `${ev.title} — EventEdge`;

  // Hero
  document.getElementById("dhImg").src = ev.image;
  document.getElementById("dhImg").alt = ev.title;
  document.getElementById("dhCat").textContent = `${CATEGORY_ICONS[ev.category] || ""} ${ev.category}`;
  document.getElementById("dhTitle").textContent = ev.title;

  // Gallery
  const galleryMain = document.getElementById("galleryMain");
  galleryMain.src = ev.gallery[0];
  document.getElementById("galleryThumbs").innerHTML = ev.gallery.map((g, i) => `
    <img src="${g}" data-i="${i}" class="${i === 0 ? "active" : ""}" alt="Gallery photo ${i + 1}">
  `).join("");
  document.querySelectorAll("#galleryThumbs img").forEach(img => {
    img.addEventListener("click", () => {
      galleryMain.src = img.src;
      document.querySelectorAll("#galleryThumbs img").forEach(i => i.classList.remove("active"));
      img.classList.add("active");
    });
  });

  // Description + tags
  document.getElementById("dDescription").textContent = ev.description;
  document.getElementById("dTags").innerHTML = ev.tags.map(t => `<span class="tag">${t}</span>`).join("");

  // Meta
  document.getElementById("dDate").textContent = formatEventDate(ev.date);
  document.getElementById("dLocation").textContent = ev.location;
  document.getElementById("dOrganizer").textContent = ev.organizer;
  document.getElementById("dCategory").textContent = ev.category;

  // Countdown
  startCountdown(ev.date, {
    d: document.getElementById("dd-d"), h: document.getElementById("dd-h"),
    m: document.getElementById("dd-m"), s: document.getElementById("dd-s")
  });

  // Price + quantity + total
  document.getElementById("dPrice").textContent = formatPrice(ev.price);
  let qty = 1;
  const qtyValue = document.getElementById("qtyValue");
  const totalPrice = document.getElementById("totalPrice");
  const registerLink = document.getElementById("registerLink");

  function updateTotal() {
    qtyValue.textContent = qty;
    totalPrice.textContent = formatPrice(qty * ev.price);
    registerLink.href = `event-registration.html?id=${ev.id}&qty=${qty}`;
    document.getElementById("qtyMinus").disabled = qty <= 1;
    document.getElementById("qtyPlus").disabled = qty >= 10;
  }
  document.getElementById("qtyMinus").addEventListener("click", () => { if (qty > 1) { qty--; updateTotal(); } });
  document.getElementById("qtyPlus").addEventListener("click", () => { if (qty < 10) { qty++; updateTotal(); } });
  updateTotal();

  // Favorite button
  const favBtn = document.getElementById("favDetailBtn");
  function renderFavBtn() {
    const fav = isFavorite(ev.id);
    favBtn.textContent = fav ? "♥ Saved to favorites" : "♡ Save to favorites";
    favBtn.classList.toggle("btn-rose", fav);
  }
  renderFavBtn();
  favBtn.addEventListener("click", () => {
    toggleFavorite(ev.id);
    renderFavBtn();
    showToast(isFavorite(ev.id) ? "Added to favorites" : "Removed from favorites");
  });

  // Related events
  const related = EVENTS.filter(e => e.category === ev.category && e.id !== ev.id).slice(0, 4);
  document.getElementById("relatedGrid").innerHTML = related.map(ticketCardHTML).join("");
  bindFavButtons();

  // Inquiry modal
  const modal = document.getElementById("inquiryModal");
  document.getElementById("inquiryBtn").addEventListener("click", () => modal.classList.add("open"));
  document.getElementById("inquiryClose").addEventListener("click", () => modal.classList.remove("open"));
  modal.addEventListener("click", (e) => { if (e.target === modal) modal.classList.remove("open"); });

  document.getElementById("inquiryForm").addEventListener("submit", (e) => {
    e.preventDefault();
    let valid = true;
    const name = document.getElementById("inqName");
    const email = document.getElementById("inqEmail");
    const message = document.getElementById("inqMessage");

    [name, email, message].forEach(f => f.closest(".form-group").classList.remove("invalid"));

    if (!name.value.trim()) { markInvalid(name, "Please enter your name"); valid = false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) { markInvalid(email, "Enter a valid email address"); valid = false; }
    if (!message.value.trim() || message.value.trim().length < 6) { markInvalid(message, "Please add a short question"); valid = false; }

    if (!valid) return;

    modal.classList.remove("open");
    document.getElementById("inquiryForm").reset();
    showToast(`Inquiry sent for "${ev.title}" — we'll reply by email.`);
  });

  function markInvalid(field, msg) {
    const group = field.closest(".form-group");
    group.classList.add("invalid");
    group.querySelector(".error-msg").textContent = msg;
  }
});
