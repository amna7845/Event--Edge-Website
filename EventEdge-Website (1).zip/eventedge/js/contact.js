document.addEventListener("DOMContentLoaded", () => {
  const fields = {
    cName: v => v.trim().length >= 2,
    cEmail: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
    cSubject: v => v !== "",
    cMessage: v => v.trim().length >= 10,
  };
  const messages = {
    cName: "Enter your full name",
    cEmail: "Enter a valid email address",
    cSubject: "Choose a subject",
    cMessage: "Message should be at least 10 characters",
  };

  function validateField(id) {
    const el = document.getElementById(id);
    const group = el.closest(".form-group");
    const ok = fields[id](el.value);
    group.classList.toggle("invalid", !ok);
    group.classList.toggle("valid", ok);
    group.querySelector(".error-msg").textContent = ok ? "" : messages[id];
    return ok;
  }

  Object.keys(fields).forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener("blur", () => validateField(id));
    el.addEventListener("input", () => validateField(id));
  });

  document.getElementById("contactForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const allValid = Object.keys(fields).map(validateField).every(Boolean);
    if (!allValid) { showToast("Please fix the highlighted fields"); return; }

    document.getElementById("contactForm").style.display = "none";
    document.getElementById("contactConfirm").style.display = "block";
    showToast("Message sent — we'll be in touch soon");
  });
});
